package com.example.criminalalertprototype.auth

import android.content.Context
import android.content.Intent
import com.example.criminalalertprototype.R
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.tasks.await

/**
 * F1 – AuthRepository
 * Handles Firebase Authentication: Email/Password + Google Sign-In.
 * All operations are suspending functions (Kotlin Coroutines) per threading requirement.
 */
class AuthRepository(private val context: Context) {

    private val firebaseAuth: FirebaseAuth = FirebaseAuth.getInstance()

    // ─── Google Sign-In client ─────────────────────────────────────────────────
    val googleSignInClient: GoogleSignInClient by lazy {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(context.getString(R.string.default_web_client_id))
            .requestEmail()
            .build()
        GoogleSignIn.getClient(context, gso)
    }

    // ─── Current user ──────────────────────────────────────────────────────────
    val currentUser: FirebaseUser? get() = firebaseAuth.currentUser

    val isLoggedIn: Boolean get() = currentUser != null

    // ─── Email / Password ──────────────────────────────────────────────────────

    /** Register a new user with email and password. */
    suspend fun registerWithEmail(email: String, password: String): Result<FirebaseUser> {
        return try {
            val result = firebaseAuth.createUserWithEmailAndPassword(email, password).await()
            Result.success(result.user!!)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /** Sign in an existing user with email and password. */
    suspend fun signInWithEmail(email: String, password: String): Result<FirebaseUser> {
        return try {
            val result = firebaseAuth.signInWithEmailAndPassword(email, password).await()
            Result.success(result.user!!)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ─── Google Sign-In ───────────────────────────────────────────────────────

    /** Exchange the Google OAuth ID token for a Firebase credential and sign in. */
    suspend fun signInWithGoogle(idToken: String): Result<FirebaseUser> {
        return try {
            val credential = GoogleAuthProvider.getCredential(idToken, null)
            val result = firebaseAuth.signInWithCredential(credential).await()
            Result.success(result.user!!)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /** Returns an Intent to launch the Google Sign-In picker. */
    fun getGoogleSignInIntent(): Intent = googleSignInClient.signInIntent

    // ─── Password Reset ───────────────────────────────────────────────────────

    /** Send a password-reset email. */
    suspend fun sendPasswordResetEmail(email: String): Result<Unit> {
        return try {
            firebaseAuth.sendPasswordResetEmail(email).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ─── Sign Out ─────────────────────────────────────────────────────────────

    /** Sign out from Firebase and Google. */
    fun signOut() {
        firebaseAuth.signOut()
        googleSignInClient.signOut()
    }
}
