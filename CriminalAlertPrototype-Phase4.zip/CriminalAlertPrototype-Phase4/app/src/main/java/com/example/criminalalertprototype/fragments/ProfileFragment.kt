package com.example.criminalalertprototype.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.criminalalertprototype.R
import com.example.criminalalertprototype.activities.LoginActivity
import com.example.criminalalertprototype.adapters.AlertAdapter
import com.example.criminalalertprototype.auth.AuthRepository
import com.example.criminalalertprototype.database.PreferenceRepository
import com.example.criminalalertprototype.database.ReportRepository
import com.example.criminalalertprototype.firebase.FirestoreHelper
import com.example.criminalalertprototype.models.AlertModel
import com.example.criminalalertprototype.models.ReportModel
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch

class ProfileFragment : Fragment() {

    private lateinit var tvUsername: TextView
    private lateinit var tvEmail: TextView
    private lateinit var tvReportCount: TextView
    private lateinit var recyclerView: RecyclerView
    private lateinit var stealthSwitch: Switch
    private lateinit var notificationGroup: RadioGroup
    private lateinit var btnDeleteAccount: Button
    private lateinit var btnLogout: Button

    private lateinit var reportRepository: ReportRepository
    private lateinit var preferenceRepository: PreferenceRepository
    private lateinit var authRepository: AuthRepository
    private var userName: String = ""
    private var userReports: List<ReportModel> = emptyList()
    private lateinit var adapter: AlertAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        authRepository       = AuthRepository(requireContext())
        reportRepository     = ReportRepository(requireContext())
        preferenceRepository = PreferenceRepository(requireContext())

        val user = FirebaseAuth.getInstance().currentUser
        userName = user?.displayName?.ifEmpty { user.email?.substringBefore("@") }
            ?: arguments?.getString("USER_NAME") ?: "User"

        setupViews(view, user)
        loadUserReports()
        loadUserPreferences()
        syncFirestoreProfile()
    }

    private fun setupViews(view: View, user: com.google.firebase.auth.FirebaseUser?) {
        tvUsername    = view.findViewById(R.id.tv_profile_username)
        tvEmail       = view.findViewById<TextView?>(R.id.tv_profile_email) ?: TextView(requireContext())
        tvReportCount = view.findViewById(R.id.tv_report_count)
        recyclerView  = view.findViewById(R.id.recycler_my_reports)
        stealthSwitch = view.findViewById(R.id.profile_stealth_switch)
        notificationGroup = view.findViewById(R.id.profile_notification_group)
        btnDeleteAccount  = view.findViewById(R.id.btn_delete_account)
        btnLogout = view.findViewById<Button?>(R.id.btn_logout) ?: Button(requireContext())

        tvUsername.text = userName
        tvEmail.text    = user?.email ?: ""

        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        adapter = AlertAdapter(emptyList()) { alert ->
            val report = ReportModel(
                id          = alert.id.toIntOrNull() ?: 0,
                firestoreId = alert.firestoreId,
                title       = alert.title,
                description = alert.description,
                category    = alert.type,
                urgency     = alert.urgency,
                location    = alert.location,
                status      = "active",
                userName    = userName
            )
            val f = CommunityDetailFragment.newInstance(report)
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, f)
                .addToBackStack(null).commit()
        }
        recyclerView.adapter = adapter

        stealthSwitch.setOnCheckedChangeListener { _, checked ->
            lifecycleScope.launch { preferenceRepository.updateStealthMode(userName, checked) }
        }
        notificationGroup.setOnCheckedChangeListener { _, id ->
            val mode = when (id) {
                R.id.profile_radio_all  -> "all"
                R.id.profile_radio_high -> "high_only"
                R.id.profile_radio_none -> "none"
                else -> "all"
            }
            lifecycleScope.launch { preferenceRepository.updateNotificationMode(userName, mode) }
        }

        btnDeleteAccount.setOnClickListener { confirmDeleteReports() }

        btnLogout.setOnClickListener {
            authRepository.signOut()
            startActivity(Intent(requireContext(), LoginActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            })
        }
    }

    /** F2 – sync user profile from Firestore */
    private fun syncFirestoreProfile() {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        lifecycleScope.launch {
            FirestoreHelper.syncUserData(uid).collect { profile ->
                if (isAdded && profile != null) {
                    stealthSwitch.isChecked = profile.stealthMode
                    when (profile.notificationMode) {
                        "all"       -> notificationGroup.check(R.id.profile_radio_all)
                        "high_only" -> notificationGroup.check(R.id.profile_radio_high)
                        "none"      -> notificationGroup.check(R.id.profile_radio_none)
                    }
                }
            }
        }
    }

    private fun loadUserReports() {
        lifecycleScope.launch {
            try {
                userReports = reportRepository.getAllReports(userName)
                tvReportCount.text = "📋 ${userReports.size} Total Reports"
                adapter.updateData(userReports.map {
                    AlertModel(id = it.id.toString(), firestoreId = it.firestoreId,
                        title = it.title, description = it.description, type = it.category,
                        timeAgo = it.createdAt.ifEmpty { "Recent" }, urgency = it.urgency, location = it.location)
                })
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadUserPreferences() {
        lifecycleScope.launch {
            try {
                val pref = preferenceRepository.getUserPreferences(userName) ?: return@launch
                stealthSwitch.isChecked = pref.stealthMode
                when (pref.notificationMode) {
                    "all"       -> notificationGroup.check(R.id.profile_radio_all)
                    "high_only" -> notificationGroup.check(R.id.profile_radio_high)
                    "none"      -> notificationGroup.check(R.id.profile_radio_none)
                }
            } catch (_: Exception) { }
        }
    }

    private fun confirmDeleteReports() {
        AlertDialog.Builder(requireContext())
            .setTitle("Delete All Reports")
            .setMessage("Are you sure you want to delete all your reports?")
            .setPositiveButton("Delete") { _, _ ->
                lifecycleScope.launch {
                    userReports.forEach { reportRepository.deleteReport(it.id) }
                    loadUserReports()
                    Toast.makeText(requireContext(), "All reports deleted", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onResume() { super.onResume(); loadUserReports() }
}
