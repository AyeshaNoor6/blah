package com.example.criminalalertprototype.activities

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.example.criminalalertprototype.firebase.FirestoreHelper
import com.example.criminalalertprototype.models.ReportModel
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch

/**
 * Jetpack Compose screen – Crime Statistics Dashboard.
 * Satisfies the requirement: "Jetpack Compose must be used for at least one new screen."
 */
class ComposeStatsActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary   = Color(0xFFE53935),
                    secondary = Color(0xFFFF7043),
                    background = Color(0xFF121212),
                    surface    = Color(0xFF1E1E1E)
                )
            ) {
                CrimeStatsDashboard(
                    onBack = { finish() }
                )
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// Composables
// ══════════════════════════════════════════════════════════════════════════════

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CrimeStatsDashboard(onBack: () -> Unit) {
    var reports by remember { mutableStateOf<List<ReportModel>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    // Collect real-time Firestore stream
    LaunchedEffect(Unit) {
        FirestoreHelper.syncActiveReports().collect { list ->
            reports  = list
            isLoading = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "📊 Crime Statistics",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF1A1A2E))
            )
        },
        containerColor = Color(0xFF121212)
    ) { padding ->

        if (isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Color(0xFFE53935))
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item { Spacer(Modifier.height(8.dp)) }

                // ── Summary cards row ────────────────────────────────────────
                item {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        StatCard(
                            modifier = Modifier.weight(1f),
                            label    = "Total Alerts",
                            value    = reports.size.toString(),
                            icon     = Icons.Filled.Notifications,
                            gradient = listOf(Color(0xFFE53935), Color(0xFFB71C1C))
                        )
                        StatCard(
                            modifier = Modifier.weight(1f),
                            label    = "High Urgency",
                            value    = reports.count { it.urgency == "High" }.toString(),
                            icon     = Icons.Filled.Warning,
                            gradient = listOf(Color(0xFFFF6F00), Color(0xFFE65100))
                        )
                    }
                }

                item {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        StatCard(
                            modifier = Modifier.weight(1f),
                            label    = "Theft Reports",
                            value    = reports.count { it.category.equals("Theft", true) }.toString(),
                            icon     = Icons.Filled.Lock,
                            gradient = listOf(Color(0xFF1565C0), Color(0xFF0D47A1))
                        )
                        StatCard(
                            modifier = Modifier.weight(1f),
                            label    = "Fire / Emergency",
                            value    = reports.count { it.category.equals("Fire", true) }.toString(),
                            icon     = Icons.Filled.LocalFireDepartment,
                            gradient = listOf(Color(0xFF6A1B9A), Color(0xFF4A148C))
                        )
                    }
                }

                // ── Category breakdown ────────────────────────────────────────
                item {
                    Text(
                        "Category Breakdown",
                        color      = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize   = 18.sp,
                        modifier   = Modifier.padding(top = 8.dp)
                    )
                }

                val categories = reports.groupBy { it.category }
                items(categories.entries.toList()) { (category, list) ->
                    CategoryProgressRow(
                        category = category,
                        count    = list.size,
                        total    = reports.size.coerceAtLeast(1)
                    )
                }

                // ── Recent alerts list ─────────────────────────────────────────
                item {
                    Text(
                        "Recent Alerts",
                        color      = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize   = 18.sp,
                        modifier   = Modifier.padding(top = 8.dp)
                    )
                }

                val recent = reports.take(5)
                if (recent.isEmpty()) {
                    item {
                        Text(
                            "No active alerts",
                            color    = Color.Gray,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                } else {
                    items(recent) { report ->
                        ReportComposeCard(report)
                    }
                }

                item { Spacer(Modifier.height(16.dp)) }
            }
        }
    }
}

@Composable
fun StatCard(
    modifier: Modifier = Modifier,
    label: String,
    value: String,
    icon: ImageVector,
    gradient: List<Color>
) {
    Card(
        modifier = modifier.height(100.dp),
        shape    = RoundedCornerShape(16.dp),
        colors   = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.linearGradient(gradient))
                .padding(12.dp)
        ) {
            Column {
                Icon(icon, contentDescription = null, tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(24.dp))
                Spacer(Modifier.height(8.dp))
                Text(value, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                Text(label, color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun CategoryProgressRow(category: String, count: Int, total: Int) {
    val fraction = count.toFloat() / total.toFloat()
    val color = when (category.lowercase()) {
        "theft"      -> Color(0xFF1565C0)
        "fire"       -> Color(0xFFE53935)
        "suspicious" -> Color(0xFFFF6F00)
        "vandalism"  -> Color(0xFF6A1B9A)
        else         -> Color(0xFF2E7D32)
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(12.dp),
        colors   = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E))
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(category, color = Color.White, fontWeight = FontWeight.Medium)
                Text("$count", color = color, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(
                progress       = { fraction },
                modifier       = Modifier.fillMaxWidth().height(6.dp),
                color          = color,
                trackColor     = Color(0xFF333333)
            )
        }
    }
}

@Composable
fun ReportComposeCard(report: ReportModel) {
    val urgencyColor = when (report.urgency) {
        "High"   -> Color(0xFFE53935)
        "Medium" -> Color(0xFFFF6F00)
        else     -> Color(0xFF2E7D32)
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(12.dp),
        colors   = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E))
    ) {
        Row(
            Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .background(urgencyColor, shape = RoundedCornerShape(5.dp))
            )
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(report.title, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text(report.location, color = Color.Gray, fontSize = 12.sp)
            }
            Surface(
                shape  = RoundedCornerShape(8.dp),
                color  = urgencyColor.copy(alpha = 0.2f)
            ) {
                Text(
                    report.urgency,
                    color    = urgencyColor,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}
