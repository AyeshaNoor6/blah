package com.example.criminalalertprototype.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.criminalalertprototype.R
import com.example.criminalalertprototype.activities.ComposeStatsActivity
import com.example.criminalalertprototype.database.ReportRepository
import com.example.criminalalertprototype.firebase.FirestoreHelper
import com.example.criminalalertprototype.models.ReportModel
import com.example.criminalalertprototype.notifications.CriminalAlertFCMService
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch

class ReportFragment : Fragment() {

    private lateinit var urgencyGroup: RadioGroup
    private lateinit var descriptionEditText: EditText
    private lateinit var locationEditText: EditText
    private lateinit var submitButton: Button
    private lateinit var btnViewStats: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var reportRepository: ReportRepository
    private var selectedCategory: String = "Theft"
    private var selectedUrgency:  String = "Low"
    private var userName: String = ""

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_report, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        userName = FirebaseAuth.getInstance().currentUser?.let {
            it.displayName?.ifEmpty { it.email?.substringBefore("@") }
        } ?: arguments?.getString("USER_NAME") ?: "User"

        reportRepository = ReportRepository(requireContext())

        setupViews(view)
        setupCategorySelection(view)
        setupUrgencySelection(view)
        setupSubmitButton(view)
    }

    private fun setupViews(view: View) {
        progressBar = view.findViewById(R.id.progress_bar_report)
        progressBar.visibility = View.GONE
        btnViewStats = view.findViewById<Button?>(R.id.btn_view_stats) ?: return
        btnViewStats.setOnClickListener {
            startActivity(Intent(requireContext(), ComposeStatsActivity::class.java))
        }
    }

    private fun setupCategorySelection(view: View) {
        val categories = mapOf(
            R.id.btn_theft      to "Theft",
            R.id.btn_vandalism  to "Vandalism",
            R.id.btn_fire       to "Fire",
            R.id.btn_suspicious to "Suspicious"
        )
        categories.forEach { (id, cat) ->
            view.findViewById<Button?>(id)?.setOnClickListener {
                selectedCategory = cat
                Toast.makeText(context, "Category: $cat", Toast.LENGTH_SHORT).show()
            }
        }
        view.findViewById<Button?>(R.id.btn_emergency)?.setOnClickListener {
            Toast.makeText(context, "EMERGENCY! Call 911 / 1122 now!", Toast.LENGTH_LONG).show()
        }
    }

    private fun setupUrgencySelection(view: View) {
        urgencyGroup = view.findViewById(R.id.urgencyGroup)
        urgencyGroup.setOnCheckedChangeListener { _, id ->
            selectedUrgency = when (id) {
                R.id.radioLow    -> "Low"
                R.id.radioMedium -> "Medium"
                R.id.radioHigh   -> "High"
                else -> "Low"
            }
        }
    }

    private fun setupSubmitButton(view: View) {
        descriptionEditText = view.findViewById(R.id.et_description)
        locationEditText    = view.findViewById<EditText?>(R.id.et_location) ?: EditText(requireContext())
        submitButton        = view.findViewById(R.id.btn_submit_report)

        submitButton.setOnClickListener {
            val description = descriptionEditText.text.toString().trim()
            val location    = locationEditText.text.toString().trim().ifEmpty { "Current Location" }
            if (description.isNotBlank()) {
                saveReport(description, location)
            } else {
                Toast.makeText(context, "Please enter a description", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun saveReport(description: String, location: String) {
        submitButton.isEnabled = false
        progressBar.visibility = View.VISIBLE

        lifecycleScope.launch {
            try {
                val report = ReportModel(
                    id          = 0,
                    title       = selectedCategory,
                    description = description,
                    category    = selectedCategory,
                    urgency     = selectedUrgency,
                    location    = location,
                    status      = "active",
                    userName    = userName
                )

                // Save to local SQLite
                reportRepository.insertReport(report)

                // Save to Firestore (F2)
                FirestoreHelper.addReport(report)

                // Show local push notification
                CriminalAlertFCMService.showLocalNotification(
                    requireContext(),
                    "New $selectedCategory Alert – $selectedUrgency Priority",
                    "📍 $location: $description"
                )

                Toast.makeText(context, "Report submitted!", Toast.LENGTH_SHORT).show()
                descriptionEditText.text.clear()
                locationEditText.text.clear()

                parentFragmentManager.setFragmentResult("report_submitted", Bundle())
                parentFragmentManager.popBackStack()
            } catch (e: Exception) {
                Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                submitButton.isEnabled = true
                progressBar.visibility = View.GONE
            }
        }
    }
}
