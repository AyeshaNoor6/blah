package com.example.criminalalertprototype.activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.criminalalertprototype.R
import com.example.criminalalertprototype.auth.AuthRepository
import com.example.criminalalertprototype.firebase.FirestoreHelper
import com.example.criminalalertprototype.models.UserProfileModel
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.common.api.ApiException
import kotlinx.coroutines.launch

/**
 * F1 – LoginActivity
 * Implements Email/Password + Google Sign-In.
 * Session persists across restarts (FirebaseAuth handles this automatically).
 */
class LoginActivity : AppCompatActivity() {

    private lateinit var authRepository: AuthRepository

    // Views
    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnLogin: Button
    private lateinit var btnRegister: Button
    private lateinit var btnGoogle: Button
    private lateinit var btnForgotPassword: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var tvToggle: TextView

    private var isLoginMode = true

    companion object {
        const val RC_GOOGLE_SIGN_IN = 9001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        authRepository = AuthRepository(this)

        // If already signed in, go straight to MainActivity
        if (authRepository.isLoggedIn) {
            navigateToMain()
            return
        }

        initViews()
        setupListeners()
    }

    private fun initViews() {
        etEmail          = findViewById(R.id.et_email)
        etPassword       = findViewById(R.id.et_password)
        btnLogin         = findViewById(R.id.btn_login)
        btnRegister      = findViewById(R.id.btn_register)
        btnGoogle        = findViewById(R.id.btn_google_signin)
        btnForgotPassword = findViewById(R.id.tv_forgot_password)
        progressBar      = findViewById(R.id.progress_bar)
        tvToggle         = findViewById(R.id.tv_toggle_mode)
    }

    private fun setupListeners() {
        btnLogin.setOnClickListener { handleEmailLogin() }
        btnRegister.setOnClickListener { handleEmailRegister() }
        btnGoogle.setOnClickListener { handleGoogleSignIn() }
        btnForgotPassword.setOnClickListener { handleForgotPassword() }

        tvToggle.setOnClickListener {
            isLoginMode = !isLoginMode
            updateModeUI()
        }
    }

    private fun updateModeUI() {
        if (isLoginMode) {
            btnLogin.visibility    = View.VISIBLE
            btnRegister.visibility = View.GONE
            tvToggle.text          = "Don't have an account? Register"
        } else {
            btnLogin.visibility    = View.GONE
            btnRegister.visibility = View.VISIBLE
            tvToggle.text          = "Already have an account? Login"
        }
    }

    // ─── Email Login ───────────────────────────────────────────────────────────
    private fun handleEmailLogin() {
        val email    = etEmail.text.toString().trim()
        val password = etPassword.text.toString().trim()
        if (!validateInputs(email, password)) return

        showLoading(true)
        lifecycleScope.launch {
            val result = authRepository.signInWithEmail(email, password)
            showLoading(false)
            result.fold(
                onSuccess = { user ->
                    syncUserToFirestore(user.uid, user.displayName ?: email.substringBefore("@"), email)
                    navigateToMain()
                },
                onFailure = { showError(it.message ?: "Login failed") }
            )
        }
    }

    // ─── Email Register ────────────────────────────────────────────────────────
    private fun handleEmailRegister() {
        val email    = etEmail.text.toString().trim()
        val password = etPassword.text.toString().trim()
        if (!validateInputs(email, password)) return
        if (password.length < 6) { showError("Password must be at least 6 characters"); return }

        showLoading(true)
        lifecycleScope.launch {
            val result = authRepository.registerWithEmail(email, password)
            showLoading(false)
            result.fold(
                onSuccess = { user ->
                    syncUserToFirestore(user.uid, email.substringBefore("@"), email)
                    navigateToMain()
                },
                onFailure = { showError(it.message ?: "Registration failed") }
            )
        }
    }

    // ─── Google Sign-In ────────────────────────────────────────────────────────
    private fun handleGoogleSignIn() {
        val signInIntent = authRepository.getGoogleSignInIntent()
        @Suppress("DEPRECATION")
        startActivityForResult(signInIntent, RC_GOOGLE_SIGN_IN)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == RC_GOOGLE_SIGN_IN) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            try {
                val account = task.getResult(ApiException::class.java)
                showLoading(true)
                lifecycleScope.launch {
                    val result = authRepository.signInWithGoogle(account.idToken!!)
                    showLoading(false)
                    result.fold(
                        onSuccess = { user ->
                            syncUserToFirestore(user.uid, user.displayName ?: "User", user.email ?: "")
                            navigateToMain()
                        },
                        onFailure = { showError(it.message ?: "Google Sign-In failed") }
                    )
                }
            } catch (e: ApiException) {
                showError("Google Sign-In cancelled or failed: ${e.statusCode}")
            }
        }
    }

    // ─── Forgot Password ───────────────────────────────────────────────────────
    private fun handleForgotPassword() {
        val email = etEmail.text.toString().trim()
        if (email.isEmpty()) { showError("Enter your email first"); return }

        lifecycleScope.launch {
            val result = authRepository.sendPasswordResetEmail(email)
            result.fold(
                onSuccess = { showMessage("Password reset email sent to $email") },
                onFailure = { showError(it.message ?: "Failed to send reset email") }
            )
        }
    }

    // ─── Helpers ───────────────────────────────────────────────────────────────
    private fun validateInputs(email: String, password: String): Boolean {
        if (email.isEmpty())    { showError("Email is required"); return false }
        if (password.isEmpty()) { showError("Password is required"); return false }
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            showError("Invalid email format"); return false
        }
        return true
    }

    private fun syncUserToFirestore(uid: String, displayName: String, email: String) {
        lifecycleScope.launch {
            FirestoreHelper.saveUserProfile(
                uid,
                UserProfileModel(uid = uid, displayName = displayName, email = email)
            )
        }
    }

    private fun navigateToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun showLoading(show: Boolean) {
        progressBar.visibility = if (show) View.VISIBLE else View.GONE
        btnLogin.isEnabled     = !show
        btnRegister.isEnabled  = !show
        btnGoogle.isEnabled    = !show
    }

    private fun showError(msg: String) =
        AlertDialog.Builder(this).setTitle("Error").setMessage(msg)
            .setPositiveButton("OK", null).show()

    private fun showMessage(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
