package com.example.criminalalertprototype.models

data class AlertModel(
    val id: String,
    val firestoreId: String = "",
    val title: String,
    val description: String,
    val type: String,
    val timeAgo: String,
    val urgency: String,
    val location: String
)
