package com.example.criminalalertprototype.activities

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.criminalalertprototype.R
import com.example.criminalalertprototype.auth.AuthRepository
import com.example.criminalalertprototype.fragments.*
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseAuth

class MainActivity : AppCompatActivity() {

    private lateinit var bottomNav: BottomNavigationView
    private lateinit var tvWelcome: TextView
    private lateinit var authRepository: AuthRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_container)

        authRepository = AuthRepository(this)

        // Guard: if user not logged in, redirect to Login
        if (!authRepository.isLoggedIn) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        setupViews()
        setupNavigation()

        supportFragmentManager.setFragmentResultListener("report_submitted", this) { _, _ ->
            refreshDashboard()
        }

        if (savedInstanceState == null) {
            loadFragment(DashboardFragment())
        }
    }

    private fun setupViews() {
        bottomNav = findViewById(R.id.bottom_navigation)
        tvWelcome = findViewById(R.id.tv_welcome)

        val user = FirebaseAuth.getInstance().currentUser
        val name = user?.displayName?.ifEmpty { user.email?.substringBefore("@") } ?: "User"
        tvWelcome.text = "Welcome back, $name!"
    }

    private fun setupNavigation() {
        bottomNav.setOnNavigationItemSelectedListener { item: MenuItem ->
            when (item.itemId) {
                R.id.nav_dashboard -> { loadFragment(DashboardFragment()); true }
                R.id.nav_report    -> {
                    val f = ReportFragment()
                    f.arguments = Bundle().apply { putString("USER_NAME", getCurrentUserName()) }
                    loadFragment(f); true
                }
                R.id.nav_alerts    -> { loadFragment(AlertsFragment()); true }
                R.id.nav_bookmarks -> {
                    val f = BookmarksFragment()
                    f.arguments = Bundle().apply { putString("USER_NAME", getCurrentUserName()) }
                    loadFragment(f); true
                }
                R.id.nav_profile   -> {
                    val f = ProfileFragment()
                    f.arguments = Bundle().apply { putString("USER_NAME", getCurrentUserName()) }
                    loadFragment(f); true
                }
                else -> false
            }
        }
    }

    fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }

    fun getCurrentUserName(): String {
        val user = FirebaseAuth.getInstance().currentUser
        return user?.displayName?.ifEmpty { user.email?.substringBefore("@") } ?: "User"
    }

    private fun refreshDashboard() {
        loadFragment(DashboardFragment())
        bottomNav.selectedItemId = R.id.nav_dashboard
    }
}
