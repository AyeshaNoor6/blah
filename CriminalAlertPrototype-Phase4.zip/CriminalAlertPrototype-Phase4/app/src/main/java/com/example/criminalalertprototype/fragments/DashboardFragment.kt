package com.example.criminalalertprototype.fragments

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.criminalalertprototype.R
import com.example.criminalalertprototype.activities.ComposeStatsActivity
import com.example.criminalalertprototype.adapters.AlertAdapter
import com.example.criminalalertprototype.database.ReportRepository
import com.example.criminalalertprototype.firebase.FirestoreHelper
import com.example.criminalalertprototype.models.AlertModel
import com.example.criminalalertprototype.models.ReportModel
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch

class DashboardFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: AlertAdapter
    private lateinit var searchEditText: EditText
    private lateinit var statsAlerts: TextView
    private lateinit var zoneStatus: TextView
    private lateinit var statsPatrols: TextView
    private lateinit var tvEmptyState: TextView
    private lateinit var reportRepository: ReportRepository
    private var alertList: List<AlertModel> = emptyList()
    private var userName: String = ""

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_dashboard, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        userName = FirebaseAuth.getInstance().currentUser?.let {
            it.displayName?.ifEmpty { it.email?.substringBefore("@") }
        } ?: arguments?.getString("USER_NAME") ?: "User"

        reportRepository = ReportRepository(requireContext())

        setupViews(view)
        setupRecyclerView(view)
        setupSearch(view)
        observeFirestoreReports()    // F2 – real-time sync
        updateActiveAlertsCount()

        // Stats button → Compose screen
        view.findViewById<Button?>(R.id.btn_stats)?.setOnClickListener {
            startActivity(Intent(requireContext(), ComposeStatsActivity::class.java))
        }
    }

    private fun setupViews(view: View) {
        statsAlerts   = view.findViewById(R.id.stats_alerts)
        zoneStatus    = view.findViewById(R.id.zone_status)
        statsPatrols  = view.findViewById(R.id.stats_patrols)
        tvEmptyState  = view.findViewById(R.id.tv_empty_state)
        zoneStatus.text   = "Safe"
        statsPatrols.text = "4"
    }

    private fun setupRecyclerView(view: View) {
        recyclerView = view.findViewById(R.id.recycler_alerts)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        adapter = AlertAdapter(emptyList()) { alert ->
            val report = ReportModel(
                id          = alert.id.toIntOrNull() ?: 0,
                firestoreId = alert.firestoreId,
                title       = alert.title,
                description = alert.description,
                category    = alert.type,
                urgency     = alert.urgency,
                location    = alert.location,
                status      = "active",
                userName    = userName
            )
            val f = CommunityDetailFragment.newInstance(report)
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, f)
                .addToBackStack(null)
                .commit()
        }
        recyclerView.adapter = adapter
    }

    private fun setupSearch(view: View) {
        searchEditText = view.findViewById(R.id.search_alerts)
        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) { performSearch(s.toString()) }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    /** F2 – Listen to Firestore in real time */
    private fun observeFirestoreReports() {
        lifecycleScope.launch {
            FirestoreHelper.syncActiveReports().collect { reports ->
                if (isAdded) {
                    if (reports.isNotEmpty()) {
                        val models = reports.map { it.toAlertModel() }
                        adapter.updateData(models)
                        showRecyclerView()
                        statsAlerts.text = reports.size.toString()
                    } else {
                        // Fall back to local SQLite
                        loadFromLocalDb()
                    }
                }
            }
        }
    }

    private fun loadFromLocalDb() {
        lifecycleScope.launch {
            try {
                val reports = reportRepository.getAllActiveReports(userName)
                if (reports.isNotEmpty()) {
                    adapter.updateData(reports.map { it.toAlertModel() })
                    showRecyclerView()
                    statsAlerts.text = reports.size.toString()
                } else {
                    showEmptyState()
                }
            } catch (_: Exception) {
                showEmptyState()
            }
        }
    }

    private fun performSearch(query: String) {
        if (query.isEmpty()) { observeFirestoreReports(); return }
        lifecycleScope.launch {
            try {
                val results = reportRepository.searchReports(userName, query)
                if (results.isNotEmpty()) {
                    adapter.updateData(results.map { it.toAlertModel() })
                    showRecyclerView()
                } else {
                    showEmptyState()
                }
            } catch (_: Exception) { }
        }
    }

    private fun updateActiveAlertsCount() {
        lifecycleScope.launch {
            try { statsAlerts.text = reportRepository.getActiveAlertsCount(userName).toString() }
            catch (_: Exception) { statsAlerts.text = "0" }
        }
    }

    private fun showEmptyState() {
        recyclerView.visibility  = View.GONE
        tvEmptyState.visibility  = View.VISIBLE
        tvEmptyState.text        = "No active alerts\n\nSubmit a report to see it here"
    }

    private fun showRecyclerView() {
        recyclerView.visibility  = View.VISIBLE
        tvEmptyState.visibility  = View.GONE
    }

    override fun onResume() {
        super.onResume()
        observeFirestoreReports()
    }

    private fun ReportModel.toAlertModel() = AlertModel(
        id          = id.toString(),
        firestoreId = firestoreId,
        title       = title,
        description = description,
        type        = category,
        timeAgo     = createdAt.ifEmpty { "Recently" },
        urgency     = urgency,
        location    = location
    )
}
