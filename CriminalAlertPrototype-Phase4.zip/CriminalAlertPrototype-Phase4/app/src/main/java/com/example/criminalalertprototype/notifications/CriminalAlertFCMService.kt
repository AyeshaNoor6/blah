package com.example.criminalalertprototype.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.criminalalertprototype.R
import com.example.criminalalertprototype.activities.MainActivity
import com.example.criminalalertprototype.firebase.FirestoreHelper
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Firebase Cloud Messaging service.
 * Handles foreground push notifications and token refresh.
 */
class CriminalAlertFCMService : FirebaseMessagingService() {

    companion object {
        const val CHANNEL_ID_ALERTS   = "criminal_alerts"
        const val CHANNEL_ID_UPDATES  = "app_updates"
        const val CHANNEL_NAME_ALERTS  = "Criminal Alerts"
        const val CHANNEL_NAME_UPDATES = "App Updates"

        /** Call this once at app start to register all notification channels. */
        fun createNotificationChannels(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val manager = context.getSystemService(NotificationManager::class.java)

                val alertsChannel = NotificationChannel(
                    CHANNEL_ID_ALERTS,
                    CHANNEL_NAME_ALERTS,
                    NotificationManager.IMPORTANCE_HIGH
                ).apply { description = "Real-time criminal activity alerts in your area" }

                val updatesChannel = NotificationChannel(
                    CHANNEL_ID_UPDATES,
                    CHANNEL_NAME_UPDATES,
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply { description = "App status updates and news" }

                manager.createNotificationChannel(alertsChannel)
                manager.createNotificationChannel(updatesChannel)
            }
        }

        /** Immediately display a local notification (e.g. when a new report is submitted). */
        fun showLocalNotification(context: Context, title: String, body: String) {
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pendingIntent = PendingIntent.getActivity(
                context, 0, intent,
                PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
            )
            val notification = NotificationCompat.Builder(context, CHANNEL_ID_ALERTS)
                .setSmallIcon(R.drawable.ic_notification_bell)
                .setContentTitle(title)
                .setContentText(body)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .build()

            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.notify(System.currentTimeMillis().toInt(), notification)
        }
    }

    // ─── Called when FCM delivers a message while the app is in foreground ────
    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)

        val title = remoteMessage.notification?.title
            ?: remoteMessage.data["title"]
            ?: "CriminalAlert"
        val body  = remoteMessage.notification?.body
            ?: remoteMessage.data["body"]
            ?: "New alert in your area"

        showLocalNotification(this, title, body)
    }

    // ─── Called when FCM issues a new registration token ──────────────────────
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        // Persist the new token to Firestore so the backend can target this device
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        CoroutineScope(Dispatchers.IO).launch {
            FirestoreHelper.updateFcmToken(uid, token)
        }
    }
}
