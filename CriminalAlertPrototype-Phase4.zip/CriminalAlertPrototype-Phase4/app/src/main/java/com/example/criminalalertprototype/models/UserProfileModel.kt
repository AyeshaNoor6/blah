package com.example.criminalalertprototype.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class UserProfileModel(
    val uid: String = "",
    val displayName: String = "",
    val email: String = "",
    val notificationMode: String = "all",
    val stealthMode: Boolean = false,
    val fcmToken: String = ""
) : Parcelable
