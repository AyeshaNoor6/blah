package com.example.criminalalertprototype.firebase

import com.example.criminalalertprototype.models.ReportModel
import com.example.criminalalertprototype.models.UserProfileModel
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

/**
 * F2 – FirestoreHelper
 * Manages two Firestore collections: "reports" and "users".
 * Uses real-time listeners (Flow) so any device change is instantly propagated.
 * All suspend operations use .await() – no blocking calls on main thread.
 */
object FirestoreHelper {

    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()

    // ─── Collection references ────────────────────────────────────────────────
    private val reportsCollection get() = db.collection("reports")
    private val usersCollection   get() = db.collection("users")

    // ══════════════════════════════════════════════════════════════════════════
    // REPORTS collection
    // ══════════════════════════════════════════════════════════════════════════

    /** Push a new criminal report to Firestore. */
    suspend fun addReport(report: ReportModel): Result<String> {
        return try {
            val data = hashMapOf(
                "title"       to report.title,
                "description" to report.description,
                "category"    to report.category,
                "urgency"     to report.urgency,
                "location"    to report.location,
                "status"      to report.status,
                "userName"    to report.userName,
                "createdAt"   to com.google.firebase.Timestamp.now()
            )
            val ref = reportsCollection.add(data).await()
            Result.success(ref.id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /** Real-time Flow of all active reports, ordered newest-first.
     *  Any remote change triggers a new emission – F2 real-time sync requirement. */
    fun syncActiveReports(): Flow<List<ReportModel>> = callbackFlow {
        val listener: ListenerRegistration = reportsCollection
            .whereEqualTo("status", "active")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) { close(error); return@addSnapshotListener }
                val reports = snapshot?.documents?.mapNotNull { doc ->
                    try {
                        ReportModel(
                            id          = doc.getLong("localId")?.toInt() ?: 0,
                            firestoreId = doc.id,
                            title       = doc.getString("title") ?: "",
                            description = doc.getString("description") ?: "",
                            category    = doc.getString("category") ?: "",
                            urgency     = doc.getString("urgency") ?: "Low",
                            location    = doc.getString("location") ?: "",
                            status      = doc.getString("status") ?: "active",
                            userName    = doc.getString("userName") ?: "",
                            createdAt   = doc.getTimestamp("createdAt")?.toDate()?.toString() ?: ""
                        )
                    } catch (e: Exception) { null }
                } ?: emptyList()
                trySend(reports)
            }
        awaitClose { listener.remove() }
    }

    /** Update the status field of a specific report document. */
    suspend fun updateReportStatus(firestoreId: String, status: String): Result<Unit> {
        return try {
            reportsCollection.document(firestoreId).update("status", status).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /** Delete a report by its Firestore document ID. */
    suspend fun deleteReport(firestoreId: String): Result<Unit> {
        return try {
            reportsCollection.document(firestoreId).delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // USERS collection
    // ══════════════════════════════════════════════════════════════════════════

    /** Save or update a user profile document (uid is the document ID). */
    suspend fun saveUserProfile(uid: String, profile: UserProfileModel): Result<Unit> {
        return try {
            val data = hashMapOf(
                "displayName"      to profile.displayName,
                "email"            to profile.email,
                "notificationMode" to profile.notificationMode,
                "stealthMode"      to profile.stealthMode,
                "fcmToken"         to profile.fcmToken,
                "updatedAt"        to com.google.firebase.Timestamp.now()
            )
            usersCollection.document(uid).set(data).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /** Real-time Flow listening to the current user's profile document.
     *  syncUserData() – satisfies F2 real-time user-data sync. */
    fun syncUserData(uid: String): Flow<UserProfileModel?> = callbackFlow {
        val listener: ListenerRegistration = usersCollection.document(uid)
            .addSnapshotListener { snapshot, error ->
                if (error != null) { close(error); return@addSnapshotListener }
                val profile = snapshot?.let {
                    UserProfileModel(
                        uid              = uid,
                        displayName      = it.getString("displayName") ?: "",
                        email            = it.getString("email") ?: "",
                        notificationMode = it.getString("notificationMode") ?: "all",
                        stealthMode      = it.getBoolean("stealthMode") ?: false,
                        fcmToken         = it.getString("fcmToken") ?: ""
                    )
                }
                trySend(profile)
            }
        awaitClose { listener.remove() }
    }

    /** Fetch a user profile once (non-realtime). */
    suspend fun getUserProfile(uid: String): UserProfileModel? {
        return try {
            val doc = usersCollection.document(uid).get().await()
            if (doc.exists()) {
                UserProfileModel(
                    uid              = uid,
                    displayName      = doc.getString("displayName") ?: "",
                    email            = doc.getString("email") ?: "",
                    notificationMode = doc.getString("notificationMode") ?: "all",
                    stealthMode      = doc.getBoolean("stealthMode") ?: false,
                    fcmToken         = doc.getString("fcmToken") ?: ""
                )
            } else null
        } catch (e: Exception) { null }
    }

    /** Store the FCM registration token under the user's Firestore document. */
    suspend fun updateFcmToken(uid: String, token: String) {
        try {
            usersCollection.document(uid).update("fcmToken", token).await()
        } catch (_: Exception) { /* best-effort */ }
    }
}
